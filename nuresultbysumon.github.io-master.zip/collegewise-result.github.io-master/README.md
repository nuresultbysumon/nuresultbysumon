# collegewise-result.github.io
View College-wise Result of National University Easily

This git has been created to facilitate viewing of college-wise result of National University of Bangladesh. 
It's very hard to view college-wise result on The University's official webpage as it requires college and subject codes which are not very easy for ordinary student to keep in mind. 

Purpose of the git is to help student view college-wise result easily without memorizing sub/college codes.

Please note that this git is unofficial and I am by no means affiliated with national university.
I can be reached @ i.never.read.mails@gmail.com
